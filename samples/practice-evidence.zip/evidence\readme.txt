Our photographer swears nothing is hidden in this picture.
The city never sleeps, and neither do its secrets.
